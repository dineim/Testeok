﻿using ConsomeApi;
using System.Text.Json;

class Program
{
    static async Task Main(string[] args)
    {
        // Filtro 2013
        string Url2013 = "https://jsonmock.hackerrank.com/api/football_matches?year=2013";

        //  Filtro  2014
        string Url2014 = "https://jsonmock.hackerrank.com/api/football_matches?year=2014";

        
        using (HttpClient httpClient = new HttpClient())
        {
            try
            {
                // Fazendo a requisição GET para a API e obtendo os dados do "team1" em 2013
                HttpResponseMessage response2013 = await httpClient.GetAsync(Url2013);

                // Verifica resultado para 2013
                if (response2013.IsSuccessStatusCode)
                {
                    // Lendo JSON
                    string jsonContent2013 = await response2013.Content.ReadAsStringAsync();

                    // Deserializando o JSON 
                    ApiResponse apiResponse2013 = JsonSerializer.Deserialize<ApiResponse>(jsonContent2013);

                    // Armazernar os gols "team1" em 2013
                    Dictionary<string, int> goalsByTeam1_2013 = new Dictionary<string, int>();

                    // Calculando o total de gols do "team1" em 2013  em todas as partidas
                    int totalGoals2013 = 0;
                    foreach (var time in apiResponse2013.data)
                    {
                        if (time.year == 2013 && int.TryParse(time.team1goals, out int goalsTeam1) && int.TryParse(time.team2goals, out int goalsTeam2))
                        {
                            // Total de gols para o "time1" em 2013
                            if (goalsByTeam1_2013.ContainsKey(time.team1))
                            {
                                goalsByTeam1_2013[time.team1] += goalsTeam1;
                            }
                            else
                            {
                                goalsByTeam1_2013[time.team1] = goalsTeam1;
                            }

                            // Total geral de gols em 2013
                            totalGoals2013 += goalsTeam1 + goalsTeam2;
                        }
                    }

                    // Exibindo o nome do "team1" e o total de gols em 2013
                    Console.WriteLine("Total de gols por time1 em 2013:");
                    foreach (var team in goalsByTeam1_2013)
                    {
                        Console.WriteLine($"Time: {team.Key}, Total de gols: {team.Value}");
                    }

                    //  gols marcados em 2013
                    Console.WriteLine($"\nTotal de gols marcados em 2013: {totalGoals2013}");
                }
                else
                {
                    // Caso a requisição falhe, imprima o código do erro e a mensagem de erro para 2013
                    Console.WriteLine($"Não tem resultados em 2013: {response2013.StatusCode} - {response2013.ReasonPhrase}");
                }

                // Requisição GET para a API  em 2014
                HttpResponseMessage response2014 = await httpClient.GetAsync(Url2014);

                // Verifica se bem sucedida para 2014
                if (response2014.IsSuccessStatusCode)
                {
                    // Lendo  JSON ---------------------------
                    string jsonContent2014 = await response2014.Content.ReadAsStringAsync();

                    // Deserializando ------------------------//
                    ApiResponse apiResponse2014 = JsonSerializer.Deserialize<ApiResponse>(jsonContent2014);

                    // Armazenar o total de gols do "team2" em 2014--------------------//
                    Dictionary<string, int> goalsByTeam2_2014 = new Dictionary<string, int>();

                    //---- Calculando o total de gols do "time2" em 2014 e o total geral de gols em todas as partidas
                    int totalGoals2014 = 0;
                    foreach (var time in apiResponse2014.data)
                    {
                        if (time.year == 2014 && int.TryParse(time.team1goals, out int goalsTeam1) && int.TryParse(time.team2goals, out int goalsTeam2))
                        {
                            // Total de gols para o "time2" em 2014
                            if (goalsByTeam2_2014.ContainsKey(time.team2))
                            {
                                goalsByTeam2_2014[time.team2] += goalsTeam2;
                            }
                            else
                            {
                                goalsByTeam2_2014[time.team2] = goalsTeam2;
                            }

                            // Total geral de gols em 2014
                            totalGoals2014 += goalsTeam1 + goalsTeam2;
                        }
                    }

                    // Exibindo o nomes dos "team2 " e o total de gols em 2014  ---------
                    Console.WriteLine("\nTotal de gols por time2 em 2014:");
                    foreach (var team in goalsByTeam2_2014)
                    {
                        Console.WriteLine($"Time: {team.Key}, Total de gols: {team.Value}");
                    }

                    // Exibindo o total  em 2014 -----------------
                    Console.WriteLine($"\nTotal de gols marcados em 2014: {totalGoals2014}");
                }
                else
                {
                    // Caso aconteça erro  para 2014
                    Console.WriteLine($"Sem dados : {response2014.StatusCode} - {response2014.ReasonPhrase}");
                }
            }
            catch (Exception ex)
            {
                // Em caso de exceção, imprima o erro
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}